﻿using ScaleManagment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TereziEla
{
    public partial class AddCard : Form
    {
        private Form1 mainForm;
        public AddCard()
        {
            InitializeComponent();
            //mainForm = form;
        }


      

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
       
            string username = textBox1.Text.Trim();
            if (!string.IsNullOrEmpty(username))
            {
                mainForm.AddUserToListView(username); // <<< mainForm artıq boş deyil
                this.Close();
            }
        }
    }
}
